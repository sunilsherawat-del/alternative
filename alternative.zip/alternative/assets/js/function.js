 
//Home car brand slider
$('.service-slider').slick({
  infinite:true,
  autoplay:false,
  slidesToShow:1,
  slidesToScroll:1,
  arrows:true,
  dots:false,
  prevArrow: '<button type="button" class="slick-prev"><i class="far fa-arrow-left"></i></button>',
  nextArrow: '<button type="button" class="slick-next"><i class="far fa-arrow-right"></i></button>',
});

//Home location slider
$('.location-slider').slick({
  infinite:true,
  autoplay:false,
  slidesToShow:4,
  slidesToScroll:1,
  arrows:true,
  dots:false,
  prevArrow: '<button type="button" class="slick-prev"><i class="far fa-arrow-left"></i></button>',
  nextArrow: '<button type="button" class="slick-next"><i class="far fa-arrow-right"></i></button>',
  
  responsive:[
    {
      breakpoint:991,
      settings: {
        slidesToShow:2,
      }
    },
    {
      breakpoint:576,
      settings: {
        slidesToShow:1,
      }
    }
  ]
});

 $('.slider-for').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  dots:false,
  fade: false,
  prevArrow: '<button type="button" class="slick-prev"><i class="far fa-arrow-left"></i></button>',
  nextArrow: '<button type="button" class="slick-next"><i class="far fa-arrow-right"></i></button>',
  asNavFor: '.slider-nav'
});
$('.slider-nav').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  asNavFor: '.slider-for',
  dots: false,
  arrows: false,
  centerMode: false,
  focusOnSelect: true,
  variableWidth: true,
  responsive:[
    {
      breakpoint:767,
      settings:{
        slidesToShow:3,
      }
    },
    {
      breakpoint:400,
      settings: {
        slidesToShow:2,
      }
    }
  ]
});


// counter scroll
$(document).ready(function () {
  var counted = 0;
  startCounter();
  function startCounter() {
    if (counted == 0) {
      $('.count').each(function () {
        var $this = $(this),
          countTo = $this.attr('data-count');

        $({ countNum: $this.text() }).animate(
          { countNum: countTo },
          {
            duration: 2000,
            easing: 'swing',
            step: function () {
              $this.text(Math.floor(this.countNum));
            },
            complete: function () {
              $this.text(this.countNum);
            },
          }
        );
      });
      counted = 1;
    }
  }
});